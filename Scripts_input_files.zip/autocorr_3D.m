function [gg,r_mod] = autocorr_3D(domain,X,Y,Z,Res_x,Res_y,Res_z,rmax)

%Wiener-Khintchine Formula for calculating autocorrelation: 
% the autocorrelation is simply given by the Fourier transform of the
% absolute square of the signal.

S2_cart = abs( fftshift(ifftn(fftn(domain) .* conj(fftn(domain)))) )./(Res_x*Res_y*Res_z);

%azimuth,elevation,r
S2_polar = S2_cart;
[azimuth,elevation,rho] = cart2sph(X,Y,Z);
S2_polar_resh = reshape(S2_polar,1,Res_y*Res_x*Res_z);
rho_resh      = reshape(rho,1,Res_y*Res_x*Res_z);
[rho_sort,ind] = sort(rho_resh);
S2_polar_sort = S2_polar_resh(ind);
[rr,aa,bb]=histcounts(rho_sort,floor(max(rho_sort)));
r_mod = 0:rmax; %0:floor(max(rho_sort))-1;
for i=1:rmax+1  %1:floor(max(rho_sort))
  gg(1,i)  = sum(S2_polar_sort(find(bb==i)))/rr(i);
end

