clc, clear all, close all

%% ----------------------------------------------------------------------
%load porous2
% 
% [filename1,filepath1]=uigetfile({'*','ascii files'},...
%     'Select Data File');
% data=load([filepath1 filename1],'dat');

prompt = {'How many 2D images:','Prefix of filename','Starting number:'};
dlg_title = 'Input files';
num_lines = [1 50];
defaultans = {'159','St-','30023'};
answer_files = inputdlg(prompt,dlg_title,num_lines,defaultans);
bfiles =char(answer_files); 
%answf=str2num(bfiles);
Nfiles=str2num(bfiles(1,:));
prefix=bfiles(2,:);
Start=str2num(bfiles(3,:));

for k=1:Nfiles
    filename=strcat(prefix,num2str(Start+k-1),'.tif');
    A=imread(filename);
    my_domain(:,:,k)=(255-A(:,:))/255;
end

domain = my_domain;%porous;

prompt = {'Enter Nx:','Enter Ny:','Enter Max R in pixels: ','Enter resolution [microns]:', 'Enter recoil distance [microns]:', 'Enter 1 is flag is 1 for aggregate, 0 otherwise:'};
dlg_title = 'Computing F-alpha from two point correlation';
num_lines = [1 50];
defaultans = {'131','179','100','1.18','15','1'};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);
b =char(answer);
answ=str2num(b);

nx=answ(1);
ny=answ(2);
rmax=answ(3);
res=answ(4);
delta=answ(5);
test=answ(6);

if test<1
    domain= 1 - domain;
end
%domain = 1 - domain;     %flag '1' for the target phase (inclusions) and '0' for all other components (continuum-phase)
%% ----------------------------------------------------------------------
[Res_y,Res_x,Res_z] = size(domain);         %resoultion of the domain
r = 0:rmax;

mask = ones(size(domain));
x = (0:(Res_x-1))-floor((Res_x)/2);
y = (0:(Res_y-1))-floor((Res_y)/2);
z = (0:(Res_z-1))-floor((Res_z)/2);
[X,Y,Z] = meshgrid(x,y,z);
phi_disk = length(find(domain))/(Res_y*Res_x*Res_z)
porosity = 1 - phi_disk
%% ---------------------------------------------------------------------

[S2,r_new] = autocorr_3D(domain,X,Y,Z,Res_x,Res_y,Res_z,rmax);
S2m=S2/S2(1);%phi_disk;

delta_pixel=delta/res;
% Interpolation
left=floor(delta_pixel);
right=ceil(delta_pixel);
fl=S2(left)/phi_disk;
fr=S2(right)/phi_disk;
f=(delta_pixel-left)*fr+(right-delta_pixel)*fl;

% Now error on 1-fa

left1=floor(delta_pixel-1);
right1=ceil(delta_pixel-1);
fl1=S2(left1)/phi_disk;
fr1=S2(right1)/phi_disk;
f1=(delta_pixel-1-left1)*fr1+(right1-delta_pixel+1)*fl1;

left2=floor(delta_pixel+1);
right2=ceil(delta_pixel+1);
fl2=S2(left2)/phi_disk;
fr2=S2(right2)/phi_disk;
f2=(delta_pixel+1-left2)*fr2+(right2-delta_pixel-1)*fl2;

%% ----------------------------------------------------------------------
x=0:0.01:delta_pixel-1;
f1v=ones(length(x))*f1;
f2v=ones(length(x))*f2;
X=[x,fliplr(x)];                %#create continuous x value array for plotting
Y=[f1v,fliplr(f2v)];              %#create y values for out and then back

figure1 = figure('units','pix','pos',[20 50 700 600])
axes1 = axes('Parent',figure1,'XMinorTick','on');
plot(r_new,S2m,'-k','linewidth',3)
xlabel('$r$','Interpreter','LaTex','FontSize',35,'fontangle','italic')
ylabel('$1-f_{\alpha}$ = $S_2(r)/S_2(0)$','Interpreter','LaTex','FontSize',35,'fontangle','italic')
title(['$1-f_{\alpha}$ = ' num2str(f) '; $\delta(1-f_{\alpha})=$ ' num2str(abs(f1-f2)/2.0)],'Interpreter','LaTex','FontSize',35)
hold on
plot(delta_pixel,f,'r*','MarkerSize',10)
line([delta_pixel-1 delta_pixel-1],[0 1],'linestyle',':')
line([delta_pixel+1 delta_pixel+1],[0 1],'linestyle',':')
line([0 delta_pixel-1],[f1 f1])
line([0 delta_pixel+1],[f2 f2])

% alpha(0.25)
% fill(X,Y,'b'); %#plot filled area
set(axes1,'FontSize',25,'FontName','Times');

for l=1:length(S2)
    output(l,1)=l;
    output(l,2)=S2(l);
end
%dlmwrite('S2_agg5.dat',output,'\t');